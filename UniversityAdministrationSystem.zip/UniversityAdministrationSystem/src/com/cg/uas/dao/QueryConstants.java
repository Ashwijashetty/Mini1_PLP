package com.cg.uas.dao;

public class QueryConstants {
public static final String getById="select * from Users where login_Id=?";
public static final String addCourse = "insert into programs_offered values(?,?,?,?,?)";
public static final String updateCourse = "update programs_offered set description=?,applicant_eligibility=? where program_name=?";
public static final String removeCourse = "delete from programs_offered where program_name=?";
public static final String viewCourse = "select * from programs_offered";
public static final String getProgramById = "select * from programs_offered where program_name=?";
public static final String addSchedule = "insert into programs_scheduled values(?,?,?,?,?,?)";
public static final String removeSchedule = "delete from programs_scheduled where program_name=?";
public static final String viewSchedule = "select * from programs_scheduled";
public static final String getScheduleById = "select * from programs_scheduled where scheduled_program_id=?";
public static final String applyDetails = "insert into application values(applicant_Id_seq.nextval,?,?,?,?,?,?,?,?,?)";
public static final String selectMaxId = "select max(application_id) from application";
public static final String getApplById = "select * from application where application_id=?";
public static final String viewAllApplById = "select * from application where scheduled_program_id=?";
public static final String updateStatus = "update application set status=? where application_id=?";
public static final String updateStatusDate="update application set status=?,date_of_interview=? where application_id=?";
}
