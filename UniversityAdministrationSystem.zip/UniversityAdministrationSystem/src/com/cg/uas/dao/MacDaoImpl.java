package com.cg.uas.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.cg.uas.exceptions.UASException;
import com.cg.uas.model.Application;
import com.cg.uas.utility.JdbcUtility;

public class MacDaoImpl implements IMacDao {
	Connection connection=null;
	PreparedStatement statement=null;
	ResultSet resultSet=null;
	
	@Override
	public List<Application> getAllApplication(String sPId) throws UASException {
		connection=JdbcUtility.getconnection();
		List<Application> list =new ArrayList<>();
			try {
				statement=connection.prepareStatement(QueryConstants.viewAllApplById);
				statement.setString(1, sPId);
			    resultSet=statement.executeQuery();
			    while(resultSet.next()) {
				int appId=resultSet.getInt(1);
			    String fName=resultSet.getString(2);
			    Date dob=resultSet.getDate(3);
			    String hq=resultSet.getString(4);
			    int marks=resultSet.getInt(5);
			    String goal=resultSet.getString(6);
			    String email=resultSet.getString(7);
			    String spId=resultSet.getString(8);
			    String status=resultSet.getString(9);
			    Date doi=resultSet.getDate(10);
	Application application=new Application(appId, fName, dob, hq, marks, goal, email, spId, status, doi);
	list.add(application);			    
			    
			    }
			    } catch (SQLException e) {
				throw new UASException("mac sql 1");
			}finally {
				try {
					statement.close();
					connection.close();
				} catch (SQLException e) {
					throw new UASException("problem while closing");
				}
			
			}
		return list;
	}

	@Override
	public int modifyWithDate(int applicationId, String stat, Date doi) throws UASException {
int value=0;
connection=JdbcUtility.getconnection();
try {
	statement=connection.prepareStatement(QueryConstants.updateStatusDate);
	Date dateI=doi;
	long ms=dateI.getTime();
	java.sql.Date date=new java.sql.Date(ms);
	statement.setString(1, stat);
	statement.setDate(2, date);
	statement.setInt(3, applicationId);
	value=statement.executeUpdate();
} catch (SQLException e) {
	throw new UASException("initial update exception of status");
}

		return value;
	}

	@Override
	public int modifyStatus(int applicationId, String status) throws UASException {
int value1=0;
connection=JdbcUtility.getconnection();

try {
	statement=connection.prepareStatement(QueryConstants.updateStatus);
	statement.setString(1, status);
	statement.setInt(2, applicationId);
	value1=statement.executeUpdate();
			

} catch (SQLException e) {
	throw new UASException("Final status update exception");
}
return value1;
}
}
