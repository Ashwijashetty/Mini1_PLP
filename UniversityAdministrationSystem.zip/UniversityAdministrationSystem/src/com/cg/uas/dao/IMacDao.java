package com.cg.uas.dao;

import java.util.Date;
import java.util.List;

import com.cg.uas.exceptions.UASException;
import com.cg.uas.model.Application;

public interface IMacDao {

	List<Application> getAllApplication(String sPId) throws UASException;

	int modifyWithDate(int applicationId, String stat, Date doi) throws UASException;

	int modifyStatus(int applicationId, String status) throws UASException;

}
