package com.cg.uas.dao;

import java.util.List;

import com.cg.uas.exceptions.UASException;
import com.cg.uas.model.Application;
import com.cg.uas.model.ProgramsScheduled;

public interface IApplicantDao {

	List<ProgramsScheduled> viewAllCourses() throws UASException;

	ProgramsScheduled getById(String sPId) throws UASException;

	boolean addDetails(Application application) throws UASException;

	int getMaxId() throws UASException;

	Application getApplById(int id) throws UASException;

}
