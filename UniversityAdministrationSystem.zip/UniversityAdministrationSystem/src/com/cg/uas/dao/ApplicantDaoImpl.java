package com.cg.uas.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.cg.uas.exceptions.UASException;
import com.cg.uas.model.Application;
import com.cg.uas.model.ProgramsScheduled;
import com.cg.uas.utility.JdbcUtility;

public class ApplicantDaoImpl implements IApplicantDao {
	Connection connection=null;
	PreparedStatement statement=null;
	ResultSet resultSet=null;
	
	@Override
	public List<ProgramsScheduled> viewAllCourses() throws UASException {
		connection=JdbcUtility.getconnection();
		List<ProgramsScheduled> list=new ArrayList<>();
			try {
				statement=connection.prepareStatement(QueryConstants.viewSchedule);
				resultSet=statement.executeQuery();
				while(resultSet.next()) {
				String scheduledProgramId=resultSet.getString(1);
				String programName=resultSet.getString(2);
				String location=resultSet.getString(3);
				java.sql.Date startDate=resultSet.getDate(4);
				java.sql.Date endDate=resultSet.getDate(5);
				int sessionsPerWeek=resultSet.getInt(6);
				ProgramsScheduled scheduled=new ProgramsScheduled(scheduledProgramId, programName, location, startDate, endDate, sessionsPerWeek);
				list.add(scheduled);
				}
			
			} catch (SQLException e) {
			throw new UASException("Applicant sql1");	
			}finally {
				try {
					statement.close();
					connection.close();
				} catch (SQLException e) {
					throw new UASException("problem while closing");
				}

			}		
		return list;
	}

	@Override
	public ProgramsScheduled getById(String sPId) throws UASException {
		connection=JdbcUtility.getconnection();
		ProgramsScheduled scheduled=new ProgramsScheduled();
		try {
			statement=connection.prepareStatement(QueryConstants.getScheduleById);
			statement.setString(1, sPId);
		    resultSet=statement.executeQuery();
		    if(resultSet.next()) {
		    scheduled.setScheduledProgramId(resultSet.getString(1));
		    scheduled.setProgramName(resultSet.getString(2));
			scheduled.setLocation(resultSet.getString(3));
			scheduled.setStartDate(resultSet.getDate(4));
	    	scheduled.setEndDate(resultSet.getDate(5));
	    	scheduled.setSessonsPerWeek(resultSet.getInt(6));
		    }
    	} catch (SQLException e) {
		throw new UASException("Applicant sql 2");	
    	}finally {
			try {
				statement.close();
				connection.close();
			} catch (SQLException e) {
				throw new UASException("problem while closing");
			}
		}
				return scheduled;
	}

	@Override
	public boolean addDetails(Application application) throws UASException {
		connection=JdbcUtility.getconnection();
		boolean flag=false;
		try {
			statement = connection.prepareStatement(QueryConstants.applyDetails);
			Date dateb=application.getDateOfBirth();
			long ms1=dateb.getTime();
			java.sql.Date dob=new java.sql.Date(ms1);
			Date datei=application.getDateOfInterview();
			long ms2=datei.getTime();
			java.sql.Date doi=new java.sql.Date(ms2);
			statement.setString(1, application.getFullName());
			statement.setDate(2, dob);
			statement.setString(3, application.getHighestQualification());
			 statement.setInt(4, application.getMarksObtained());
		        statement.setString(5, application.getGoals());
		        statement.setString(6, application.getEmailId());
		        statement.setString(7, application.getScheduledProgramId());
		        statement.setString(8, application.getStatus());
		        statement.setDate(9, doi);
		        int result=statement.executeUpdate();
		        if(result>0)
		        	flag=true;
				
		} catch (SQLException e) {
		throw new UASException("Applicant sql 2");	
		}finally {
			try {
				statement.close();
				connection.close();
			} catch (SQLException e) {
				throw new UASException("problem while closing");
			}

		}		

       return flag;
	}

	@Override
	public int getMaxId() throws UASException {
		connection=JdbcUtility.getconnection();
		int id=0;
		try {
			statement = connection.prepareStatement(QueryConstants.selectMaxId);
			resultSet = statement.executeQuery();
			resultSet.next();
			id = resultSet.getInt(1);

		} catch (SQLException e) {
			throw new UASException("applicant id sql 3");
		}finally {
			try {
				statement.close();
				connection.close();
			} catch (SQLException e) {
				throw new UASException("problem while closing");
			}

		}		
return id;
	}

	@Override
public Application getApplById(int id) throws UASException {
connection=JdbcUtility.getconnection();
Application application=new Application();
try {
	statement = connection.prepareStatement(QueryConstants.getApplById);
	statement.setInt(1, id);
	resultSet=statement.executeQuery();

	if(resultSet.next()) {
		application.setApplicationId(resultSet.getInt(1));
		application.setFullName(resultSet.getString(2));
		application.setDateOfBirth(resultSet.getDate(3));
		application.setHighestQualification(resultSet.getString(4));
		application.setMarksObtained(resultSet.getInt(5));
		application.setGoals(resultSet.getString(6));
		application.setEmailId(resultSet.getString(7));
		application.setScheduledProgramId(resultSet.getString(8));
		application.setStatus(resultSet.getString(9));
		application.setDateOfInterview(resultSet.getDate(10));
	
	}
} catch (SQLException e) {
throw new UASException("applicant dao sql 4");
}finally {
	try {
		statement.close();
		connection.close();
	} catch (SQLException e) {
		throw new UASException("problem while closing");
	}
			}return application;


	}
	
}
