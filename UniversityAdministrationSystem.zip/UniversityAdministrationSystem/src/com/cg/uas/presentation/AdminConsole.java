package com.cg.uas.presentation;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

import com.cg.uas.exceptions.UASException;
import com.cg.uas.model.Application;
import com.cg.uas.model.ProgramsOffered;
import com.cg.uas.model.ProgramsScheduled;
import com.cg.uas.service.AdminServiceImpl;
import com.cg.uas.service.IAdminService;

public class AdminConsole {
	private String currentUser;
	IAdminService adminService = new AdminServiceImpl();

	public AdminConsole(String currentUser) {
		super();
		this.currentUser = currentUser;
	}

	Scanner scanner = new Scanner(System.in);

	public void start() throws UASException {
		System.out.println("Welcome " + currentUser);
		boolean n = false;
		while (n != true) {

			System.out.println(
					"1] Add Courses 2]Update Courses 3]Remove Courses 4]Schedule a program 5]View application based on status 6]Logout");
			int choice = 0;
			try {
				choice = scanner.nextInt();
			} catch (InputMismatchException e) {
				throw new UASException("Invalid option");
			}
			switch (choice) {
			case 1:
				addCourse();
				break;
			case 2:
				updateCourse();
				break;
			case 3:
				removeCourse();
				break;
			case 4:
				scheduleProgram();
				break;
			case 5:
				System.out.println(
						"Choose 1]Applied 2] Accepted applications 3]Confirmed applications 4]Rejected applicants ");
				int val = 0;
				try {
					val = scanner.nextInt();
					List<Application> list = statusBasedView(val);
					if(!list.isEmpty()) {
						for(Application app:list) {
					System.out.println("Application Id: " + app.getApplicationId() + "\nStatus: " + app.getStatus()
							+ "\tName: " + app.getFullName() + "\nDate of birth: " + app.getDateOfBirth()
							+ "\tHighest qualification: " + app.getHighestQualification() + "\nMarks :"
							+ app.getMarksObtained() + "\tGoals: " + app.getGoals() + "\nEmail: " + app.getEmailId()
							+ "\tScheduled Id: " + app.getScheduledProgramId());
						}
						}else {
							
						System.out.println("NO APPLICANTS FOR CHOSEN STATUS");
					}
					} catch (InputMismatchException e) {
					throw new UASException("Invalid choice ");
				}
				break;
			case 6:
				n = true;
				System.out.println("Exit success");
				break;
			default:
				System.out.println("Invalid input chosen");
				System.exit(0);
				break;
			}
		}
	}

	private List<Application> statusBasedView(int val) throws UASException {
		List<Application> app= new ArrayList<>();
		if (val == 1) {
			String stat = "APPLIED";
			app = adminService.statusBasedView(stat);
		} else if (val == 2) {
			String stat2 = "ACCEPTED";
			app = adminService.statusBasedView(stat2);
		} else if (val == 3) {
			String stat3 = "CONFIRMED";
			app = adminService.statusBasedView(stat3);
		} else if (val == 4) {
			String stat4 = "REJECTED";
			app = adminService.statusBasedView(stat4);
		} else {
			System.out.println("Invalid status choice");
		}
		return app;
	}

	private void scheduleProgram() throws UASException {
		System.out.println("The available programs are :");
		List<ProgramsOffered> list = adminService.getAllCourses();
		if (!list.isEmpty()) {
			for (ProgramsOffered off : list) {
				System.out.println("Program Name : " + off.getProgramName() + "\nDescription : " + off.getDescription()
						+ "\nEligibility : " + off.getApplicantEligibility() + "\nCourse Duration : "
						+ off.getDuration() + "\nCertificate : " + off.getDegreeCertificateOffered());
			}

			System.out.println("Enter the program name which has to be scheduled ");
			scanner.nextLine();
			String cName = scanner.nextLine();
			ProgramsOffered offered = adminService.getByName(cName);
			if (offered.getProgramName() == null) {
				System.out.println("Course name entered does not exist : ");
			} else {
				System.out.println("1]Add schedule 2]Delete schedule");
				int sch = scanner.nextInt();
				if (sch == 1) {
					System.out.println(offered.getProgramName());
					ScheduleProg(offered.getProgramName());
				} else if (sch == 2) {
					// ScheduleDelete(offered.getProgramName());
					int res = adminService.ScheduleDelete(offered.getProgramName());
					if (res > 0)
						System.out.println("Deleted schedule successfully");
					else {
						System.out.println("Not deleted schedule");
					}
				} else {
					System.out.println("Invalid number chosen");
				}
			}
		} else {
			System.out.println("No courses to schedule");
		}
	}

	private void ScheduleProg(String pName) throws UASException {
		try {
			System.out.println("Enter the id for scheduled program" + pName);
			scanner.nextLine();
			String scheduledProgramId = scanner.nextLine();
			System.out.println("Enter location : ");
			String location = scanner.nextLine();
			System.out.println("Enter start date");
			String sstartDate = scanner.nextLine();
			System.out.println("Enter end date");
			String sendDate = scanner.nextLine();
			System.out.println("Enter number of sessions per week");
			int spw = scanner.nextInt();
			SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");

			Date startDate = sdf.parse(sstartDate);
			Date endDate = sdf.parse(sendDate);
			ProgramsScheduled scheduled = new ProgramsScheduled(scheduledProgramId, pName, location, startDate, endDate,
					spw);
			String PId = adminService.addSchedule(scheduled);
			System.out.println("The data is scheduled with Program id : " + PId);

		} catch (ParseException e) {
			throw new UASException("date parse exception");
		}

	}

	private void removeCourse() throws UASException {

		System.out.println("Enter name of course to be removed");
		scanner.nextLine();
		String cname = scanner.nextLine();
		System.out.println(cname);
ProgramsScheduled scheduled=adminService.getScheduleByName(cname);
if(!scheduled.getProgramName().equals(cname)) {
	System.out.println("The course details to be removed is "+scheduled.getProgramName()+", "+scheduled.getScheduledProgramId());
		int result = adminService.removeCourse(cname);
		if (result > 0)
			System.out.println("deleted successfully" + result);
		else {
			System.out.println("No such course exist to delete/Not deleted");
		}}else {
			System.out.println("Cant delete because as it is scheduled "+scheduled.getScheduledProgramId());
		}
	}

	private void updateCourse() throws UASException {

		System.out.println("Enter Program Name to be updated");
		scanner.nextLine();
		String pname1 = scanner.nextLine();
		System.out.println(pname1);
		System.out.println("enter description");
		String description = scanner.nextLine();
		System.out.println("Enter eligibility");
		String eligibility = scanner.nextLine();
		System.out.println(eligibility);
		ProgramsOffered offered = new ProgramsOffered(pname1, description, eligibility);
		int updateRes = adminService.updateCourse(offered);
		System.out.println(updateRes);
		if (updateRes > 0)
			System.out.println("Update successful");
		else {
			System.out.println("Not updated ");
		}

	}

	private void addCourse() throws UASException {
		System.out.println("Already existing programs are :");
		List<ProgramsOffered> list = adminService.getAllCourses();
		if (!list.isEmpty()) {
			for (ProgramsOffered off : list) {
				System.out.println("Program Name : " + off.getProgramName() + "\nDescription : " + off.getDescription()
						+ "\nEligibility : " + off.getApplicantEligibility() + "\nCourse Duration : "
						+ off.getDuration() + "\nCertificate : " + off.getDegreeCertificateOffered());
			}}

System.out.println("ENTER THE DETAILS FOR NEW PROGRAM");
		scanner.nextLine();
		System.out.println("Enter program Name:");
		String pname = scanner.nextLine();
		System.out.println("Description of course");
		String desc = scanner.nextLine();
		System.out.println("eligibility");
		String ae = scanner.nextLine();
		System.out.println("Program duration");
		int d = scanner.nextInt();
		scanner.nextLine();
		System.out.println("Certificate Provided");
		String dc = scanner.nextLine();
		ProgramsOffered offered = new ProgramsOffered(pname, desc, ae, d, dc);
		String pName = adminService.addCouse(offered);
		System.out.println("Course " + pName);
	}

}
