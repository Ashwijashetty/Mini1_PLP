package com.cg.uas.presentation;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

import com.cg.uas.exceptions.UASException;
import com.cg.uas.model.Application;
import com.cg.uas.model.ProgramsScheduled;
import com.cg.uas.service.ApplicantServiceImpl;
import com.cg.uas.service.IApplicantService;

public class ApplicantConsole {
	Scanner scanner = new Scanner(System.in);
	IApplicantService applicantService = new ApplicantServiceImpl();

	public void start() throws UASException {
		System.out.println("Welcome !!");
		boolean loop=false;
		while (loop!=true) {
		System.out.println("1] View courses, 2]Apply, 3]Check Status 4]Exit ");
		int choice=0;
		try {
		choice = scanner.nextInt();
		}catch (InputMismatchException e){
			throw new UASException("Invalid option");
		}
		switch (choice) {
		case 1:
			viewScheduledCourses();
			break;

		case 2:
			apply();
			break;

		case 3:
			checkStatus();
			break;
		case 4:
			System.out.println("Exit from Applicant");
			loop=true;
			break;
		default:
			System.out.println("Invalid option chosen");
			break;
		}
	}
	}
private void checkStatus() throws UASException{
	System.out.println("Enter applicant id: ");
	int id=scanner.nextInt();
	Application appl=applicantService.getApplById(id);
	if(appl.getApplicationId()!=id) {
		System.out.println("ID do not exist");
	}
	if("APPLIED".equals(appl.getStatus())) {
	System.out.println("Welcome "+appl.getFullName()+
			",\nSTATUS : "+appl.getStatus());
	}else if("ACCEPTED".equals(appl.getStatus())) {
		System.out.println("Welcome "+appl.getFullName()+"\nSTATUS : "+appl.getStatus()+"\nYour interview is scheduled on: "+appl.getDateOfInterview());
	}else if("REJECTED".equals(appl.getStatus())) {
		System.out.println("Dear "+appl.getFullName()+",your application is been rejected ");
		
	}else if("CONFIRMED".equals(appl.getStatus())){
		System.out.println("Congratulations!!! and your participant details are :");
	}
	}

private Application readApplicantDetails(String pId) throws UASException {
    try {
	
    System.out.println("Enter full name: ");
    String fName=scanner.nextLine();
    System.out.println("Date of birth: ");
    String dobirth=scanner.nextLine();
    System.out.println("highest qualification");
    String hq=scanner.nextLine();
    System.out.println("Marks Obtained: ");
    int marks=scanner.nextInt();
    scanner.nextLine();
    System.out.println("Goals");
    String goal=scanner.nextLine();
    System.out.println("emailid");
    String emailId=scanner.nextLine();
    String progId=pId;
    String status="APPLIED";
    SimpleDateFormat sdf=new SimpleDateFormat("dd/MM/yyyy");
    
		Date dateOfBirth=sdf.parse(dobirth);
	Date dt=new Date();
    Application application=new Application(fName, dateOfBirth, hq, marks, goal, emailId, progId, status, dt);
    return application;
    
    } catch (ParseException e) {
    	throw new UASException("dob error");	
    	}
        
    
	}

	private void viewScheduledCourses() throws UASException {
		List<ProgramsScheduled> list = applicantService.viewAllCourses();
		if (!list.isEmpty()) {
			
			for (ProgramsScheduled sch : list) {
			
				System.out.println("ScheduledProgram Id: " + sch.getScheduledProgramId() + "\tProgram location"
						+ sch.getProgramName() + "\tProgrm location" + sch.getLocation() + "\tStart date"
						+ sch.getStartDate() + "\tEnd date" + sch.getEndDate() + "\tSessions per week"
						+ sch.getSessonsPerWeek());

			}

		} else {
			System.out.println("No scheduled courses available");
			System.exit(0);
		}
	}

	private void apply() throws UASException {
		List<ProgramsScheduled> list = applicantService.viewAllCourses();
		if (!list.isEmpty()) {
			for (ProgramsScheduled sch : list) {
				System.out.println("Courses available are :" + "\tProgram_Id :" + sch.getScheduledProgramId()
						+ "\tProgram Name: " + sch.getProgramName());
			}
		}
		System.out.println("Enter Id of Program desired to apply : ");
		scanner.nextLine();
		String sPId = scanner.nextLine();
		ProgramsScheduled scheduled = applicantService.getById(sPId);
		if (scheduled.getProgramName() == null)
			System.out.println("Scheduled Program Id entered does not exist" + scheduled.getProgramName());
		else {
			System.out.println("You chose  " + scheduled.getProgramName());
			Application application=readApplicantDetails(scheduled.getScheduledProgramId());
			boolean result=applicantService.addDetails(application);
			if(result) {
				int id=applicantService.getMaxId();
				System.out.println("Applied with applicant id: "+id);
			}else {
				System.out.println("Not Applied");
			}
		}
	}


}
