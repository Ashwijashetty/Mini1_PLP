package com.cg.uas.presentation;

import java.util.InputMismatchException;
import java.util.Scanner;

import com.cg.uas.exceptions.UASException;
import com.cg.uas.service.IUserService;
import com.cg.uas.service.UserServiceImpl;

public class Main {
public static void main(String[] args) throws UASException {
	IUserService service=new UserServiceImpl();
	Scanner scanner=new Scanner(System.in);
	boolean flag=true;
	while (flag) {
		
	
	System.out.println("Enter as 1] Student ,2]Admin or Mac,3]Exit");
	int choice=0;
	try {
		choice=scanner.nextInt();
	}catch(InputMismatchException e) {
		throw new UASException("Invalid choice");
	}
	switch (choice) {
	  case 1:
		ApplicantConsole apc=new ApplicantConsole();
		apc.start();
		break;
      case 2:
    	  scanner.nextLine();
    	  System.out.println("Enter loginId:");
    		String loginId=scanner.nextLine();
    		System.out.println("Password:");
    		String password=scanner.nextLine();
    		String role=service.getRole(loginId,password);
    		System.out.println("The role is :"+role);
    	    if(role.equals("admin")){
    		AdminConsole ac=new AdminConsole(loginId);
    		ac.start();
    	    }else if(role.equals("mac")) {
    	    	MacConsole mc=new MacConsole(loginId);
    	    	mc.start();
    	    }
		break;
      case 3:
    	  System.out.println("Exit successful");
    	  flag=false;
	 break;
      default:
		  System.out.println("Invalid option chosen");
		  
		break;
	
	}
}

}
}
