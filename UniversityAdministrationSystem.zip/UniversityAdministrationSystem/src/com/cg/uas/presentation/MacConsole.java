package com.cg.uas.presentation;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Scanner;

import com.cg.uas.exceptions.UASException;
import com.cg.uas.model.Application;
import com.cg.uas.model.ProgramsScheduled;
import com.cg.uas.service.ApplicantServiceImpl;
import com.cg.uas.service.IApplicantService;
import com.cg.uas.service.IMacService;
import com.cg.uas.service.MacServiceImpl;

public class MacConsole {
	private String name;
	IApplicantService appService = new ApplicantServiceImpl();
	IMacService macService = new MacServiceImpl();
	Scanner scanner = new Scanner(System.in);

	public MacConsole(String name) {
		super();
		this.name = name;
	}

	public void start() throws UASException {
		boolean repeat=true;
		while (repeat) {
			
		
		System.out.println("1] View applications by scheduled programs Id" + "\n2] Accept or Reject an application"
				+ "\n3] Confirm or Reject" + "\n4] LogOut");
		int choice = scanner.nextInt();
		
		switch (choice) {
		case 1:
			viewByProgramId();
			break;
		case 2:
			Application app=statusUpdate();
			boolean flag=true;
			int val=0;
			try {
			while(flag) {
			if(app.getStatus().equals("APPLIED")) {
				System.out.println("1] Accept 2]Reject");
				int key=scanner.nextInt();
				if(key==1) {
					System.out.println("Enter date of interview");
					scanner.nextLine();
					String dateI=scanner.nextLine();
					SimpleDateFormat simpleDateFormat=new SimpleDateFormat("dd/MM/yyyy");
					
						Date doi=simpleDateFormat.parse(dateI);
					
					String stat="ACCEPTED";
				val=macService.modifyWithDate(app.getApplicationId(),stat,doi);
				System.out.println("Accepted");
				flag=false;
				}else if(key==2) {
					String stat="REJECTED";
				val=macService.modifyStatus(app.getApplicationId(),stat);
				System.out.println("Rejected");
				flag=false;
				}else {
					System.out.println("Invalid option");
				}
				
			}else {
				System.out.println("No applications");
				flag=false;
			}}} catch (ParseException e) {
				throw new UASException("date set for interview exception");	
				}
				
			if(val<0) {
			System.out.println("No updated");
			}
			break;
		case 3:
			Application app2=statusUpdate();
			int val1=0;
			boolean flag1=true;
			while(flag1) {
			if(app2.getStatus().equals("ACCEPTED")) {
				System.out.println("1] Confirm 2]Reject");
				int key=scanner.nextInt();
				if(key==1) {
					String stat="CONFIRMED";
					val1=macService.modifyStatus(app2.getApplicationId(),stat);
				System.out.println("Confirmed");
				flag1=false;
				}else if(key==2) {
					String stat="REJECTED";
				val1=macService.modifyStatus(app2.getApplicationId(),stat);
				System.out.println("Rejected");
				flag1=false;
				}else {
					System.out.println("Invalid option");
				}
				
			}else {
				System.out.println("No applications");
				flag1=false;
			}
			}if(val1<0) {
				System.out.println("Not updated");
			}
			break;
		case 4:
			System.out.println("Logged out from MAC");
			repeat=false;
			break;

		default:
			System.out.println("Invalid option chosen");
			break;
		}
	}}

	private Application statusUpdate() throws UASException {
		System.out.println("Enter application id");
		int id=scanner.nextInt();
		Application app=appService.getApplById(id);

		if(app.getApplicationId()!=id) 
			System.out.println("Doesn't exist");
		else {
		System.out.println(String.format("\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s",
				app.getApplicationId(), app.getFullName(), app.getDateOfBirth(),
				app.getHighestQualification(), app.getMarksObtained(), app.getGoals(), app.getEmailId(),
				app.getScheduledProgramId(), app.getStatus(), app.getDateOfInterview()));
		}
		return app;
	}

	private void viewByProgramId() throws UASException {
		System.out.println("Available courses are ");
		List<ProgramsScheduled> list = appService.viewAllCourses();
		if (list != null) {
			for (ProgramsScheduled sch : list) {
				System.out.println("\nCourses available are :" + "\tProgram_Id :" + sch.getScheduledProgramId()
						+ "\tProgram Name: " + sch.getProgramName());

			}
		}
		System.out.println("Enter Id of Program desired to apply : ");
		scanner.nextLine();
		String sPId = scanner.nextLine();
		ProgramsScheduled scheduled = appService.getById(sPId);
		boolean flag=true;
		if (scheduled.getProgramName() == null) {
			System.out.println("Chosen program does not exist");
		} else {
			System.out.println("For  "+scheduled.getProgramName());
			List<Application> applications = macService.getAllApplication(sPId);
			if (applications != null) {
				
				for (Application appl : applications) {
					flag=false;
					System.out.println(String.format("\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s",
							appl.getApplicationId(), appl.getFullName(), appl.getDateOfBirth(),
							appl.getHighestQualification(), appl.getMarksObtained(), appl.getGoals(), appl.getEmailId(),
							appl.getScheduledProgramId(), appl.getStatus(), appl.getDateOfInterview()));

				}if(flag) {
					System.out.println("No applicants");
				}
					}
				}
			}
		}

	
