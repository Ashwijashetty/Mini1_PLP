package com.cg.uas.service;

import java.util.Date;
import java.util.List;

import com.cg.uas.dao.IMacDao;
import com.cg.uas.dao.MacDaoImpl;
import com.cg.uas.exceptions.UASException;
import com.cg.uas.model.Application;

public class MacServiceImpl implements IMacService {
IMacDao macDao=new MacDaoImpl();
	@Override
	public List<Application> getAllApplication(String sPId) throws UASException {
		return macDao.getAllApplication(sPId);
	}
	@Override
	public int modifyStatus(int applicationId, String status) throws UASException {
		return macDao.modifyStatus(applicationId,status);
		
	}
	@Override
	public int modifyWithDate(int applicationId, String stat, Date doi) throws UASException {

		return macDao.modifyWithDate(applicationId,stat,doi);
	}
	
}
