package com.cg.uas.service;

import java.util.List;

import com.cg.uas.dao.ApplicantDaoImpl;
import com.cg.uas.dao.IApplicantDao;
import com.cg.uas.exceptions.UASException;
import com.cg.uas.model.Application;
import com.cg.uas.model.ProgramsScheduled;

public class ApplicantServiceImpl implements IApplicantService {
IApplicantDao applicantDao=new ApplicantDaoImpl();
	@Override
	public List<ProgramsScheduled> viewAllCourses() throws UASException {
		return applicantDao.viewAllCourses();
	}
	@Override
	public ProgramsScheduled getById(String sPId) throws UASException {
		return applicantDao.getById(sPId);
	}
	@Override
	public int getMaxId() throws UASException {
		// TODO Auto-generated method stub
		return applicantDao.getMaxId();
	}
	@Override
	public boolean addDetails(Application application) throws UASException {
		
		return applicantDao.addDetails(application);
	}
	@Override
	public Application getApplById(int id) throws UASException{
		// TODO Auto-generated method stub
		return applicantDao.getApplById(id);
	}

}
