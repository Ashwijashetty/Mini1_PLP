package com.cg.uas.service;

import java.util.List;

import com.cg.uas.exceptions.UASException;
import com.cg.uas.model.Application;
import com.cg.uas.model.ProgramsScheduled;

public interface IApplicantService {

	List<ProgramsScheduled> viewAllCourses() throws UASException;

	ProgramsScheduled getById(String sPId) throws UASException;

	int getMaxId() throws UASException;

	boolean addDetails(Application application) throws UASException;

	Application getApplById(int id) throws UASException;

}
