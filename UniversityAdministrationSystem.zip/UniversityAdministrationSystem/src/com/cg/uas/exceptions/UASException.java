package com.cg.uas.exceptions;

public class UASException extends Exception{

private static final long serialVersionUID = 1L;
public UASException(String message){
	super(message);
	
}
public UASException(){
}
}
